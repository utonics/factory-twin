# FactoryTwin 실습 안내 — 컴퓨터메이트 개발자 교육

스마트 팩토리 디지털 트윈(FactoryTwin)을 Claude Code로 만든 과정을 직접 따라 해 보는 실습 저장소입니다.
강의에서 본 프롬프트 20건은 `prompts/`에, 팀 규칙 예시는 `CLAUDE.md`에 있습니다.

## 0. 준비 (10분)

| 항목 | 확인 |
|---|---|
| Node.js 22.12 이상 | `node -v` |
| Git | `git --version` |
| Claude Code 로그인 | `claude` 실행 후 로그인 |
| WebGL이 되는 최신 브라우저 | Chrome·Edge 권장 |

```bash
unzip factory-twin-lab.zip && cd factory-twin-lab
npm ci
npm test          # 테스트 통과 확인
npm run dev       # http://localhost:5173 에서 공장이 움직이면 준비 완료
```

## 실습

| 실습 | 시간 | 브랜치 | 카드 |
|---|---|---|---|
| 1 따라하기 — 3라인 추가 | 35분 | `main`에서 새 브랜치 | `lab/01-follow.md` |
| 2 고쳐보기 — 멈추는 AGV | 35분 | `lab/bug-agv` | `lab/02-fix.md` |
| 3 기록하기 — 내 도메인 디지털 트윈 | 과제(1주) | 빈 폴더 | `lab/03-record.md` |

> 강사 실측(2026-10-14, Claude Code를 대화 없이 한 번에 실행): 실습 1 약 3분, 실습 2 약 6.5분(설명 4.6분 + 수정 1.9분).
> 실제 실습에서는 질문에 답하고 결과를 확인·기록하는 시간이 더해지므로 각 35분으로 잡았습니다.

## 완료 기준 (모든 실습 공통)

1. 화면으로 확인한다(`npm run dev`)
2. `npm test` → `npx tsc --noEmit` → `npm run build`가 모두 통과한다
3. 프롬프트와 결과를 워크북(또는 `prompts/00-template.md` 틀)에 기록한다

## 막혔을 때

- **강의의 단계로 이동**: 저장소에는 실제 제작 단계별 태그가 있습니다.

  | 태그 | 상태 |
  |---|---|
  | `step-1` | 3D 애니메이션 + 가상 데이터 파이프라인 |
  | `step-2` | 구역 선택 · 물류 KPI · 필터 |
  | `step-3` | 코드 점검 · 인스턴싱 |
  | `step-4` | AGV 충전 베이 분리 |
  | `step-5` | 운영 버그 수정 · 셰이더 미리 컴파일(최종) |

  ```bash
  git switch --detach step-2     # 그 단계 코드 보기
  git switch main                # 돌아오기
  ```
- **실습 1 예시 정답**: `lab/answer-line3` 브랜치
- **실습 2 정답**: `main` 브랜치의 코드(스스로 찾은 뒤에 비교)
- **흔한 오류**: Node 버전이 낮으면 `npm ci`가 실패합니다. 포트 5173이 쓰이고 있으면 `npm run dev -- --port 5174`.

## 규칙

- 커밋은 로컬에만 합니다. 이 저장소에는 원격이 없습니다.
- 실습에 실제 회사·개인 데이터를 넣지 않습니다.
